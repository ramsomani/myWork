package com.yash;

import java.util.HashMap;
import java.util.Map;

public interface Mymap {
		public abstract void put(Object key,Object value);
		
		
}
